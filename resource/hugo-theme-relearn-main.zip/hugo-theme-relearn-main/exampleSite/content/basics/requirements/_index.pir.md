+++
categories = "basic"
disableToc = true
title = "Requirrrements"
weight = 10
+++
{{< piratify >}}