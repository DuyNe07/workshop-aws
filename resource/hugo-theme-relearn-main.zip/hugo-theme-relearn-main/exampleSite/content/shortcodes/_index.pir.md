+++
archetype = "chapter"
title = "Shorrrtcodes"
ordersectionsby = "title"
weight = 3
+++
{{< piratify >}}