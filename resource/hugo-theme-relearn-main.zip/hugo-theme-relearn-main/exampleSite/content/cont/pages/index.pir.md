+++
title = "planks orrrganizat'n"
weight = 1
+++
{{< piratify >}}