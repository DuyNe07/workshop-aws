+++
title = "Arrrchetypes"
weight = 3
+++
{{< piratify >}}