+++
archetype = "home"
description = "A theme for Hugo designed for documentation."
title = "Hugo Relearn Theme"
+++
{{% replaceRE "https://mcshelby.github.io/hugo-theme-relearn/" "" %}}
{{< include "README.md" "true" >}}
{{% /replaceRE %}}