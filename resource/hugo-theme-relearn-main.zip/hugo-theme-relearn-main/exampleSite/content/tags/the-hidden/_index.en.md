+++
title = "a secret"
+++

This lists all pages that are hidden from the home page. This includes pages that define `hidden=true` in their frontmatter as well as descendents of hidden pages.

When giving term pages, you should give it a title. Otherwise it will print out a warning and will use the urlized title, which may looks weird.

While internally this term is called `hidden`, it is referenced in the resulting english pages as `a secret` and as `hush, matey` in the piratish translation.

## Just an example heading

The TOC will contain this heading and the index headings below.
